/* ------------------------- */
/* --- test_acceleroNR.c --- */
/* ------------------------- */

/*
 * Copyright (c) 2016 Lionel Lacassagne, all rights reserved
 * UPMC LIP6
 */

#ifndef __TEST_ACCELERO_NR_H__
#define __TEST_ACCELERO_NR_H__

#ifdef __cplusplus
extern "C" {
#endif
    
int test_acceleroNR(int argc, const char * argv[]);

#ifdef __cplusplus
}
#endif

#endif // __TEST_ACCELERO_NR_H__